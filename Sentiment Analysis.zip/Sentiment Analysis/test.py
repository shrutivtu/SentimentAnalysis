projectTwitterDataFile = open("project_twitter_data.csv", "r")
resultingDataFile = open("resulting_data.csv", "w")

punctuation_chars = ["'", '"', ",", ".", "!", ":", ";", '#', '@']
# list of positive words to use
positive_words = set()
with open("positive_words.txt") as pos_f:
    for lin in pos_f:
        if lin[0] != ';' and lin[0] != '\n':
            positive_words.add(lin.strip())

negative_words = set()
with open("negative_words.txt") as pos_f:
    for lin in pos_f:
        if lin[0] != ';' and lin[0] != '\n':
            #negative_words.append(lin.strip())
                negative_words.add(lin.strip())


def strip_punctuation(str1):
    for ch in punctuation_chars:
        if ch in str1:
            str1 = str1.replace(ch, "")
    return str1


def get_pos(str2):
    words = str2.lower().split(" ")
    posi = 0
    for word in words:
        #for pos in positive_words:
        if word in positive_words:
                posi += 1
    return posi

def get_neg(str3):
    words = str3.lower().split(" ")
    nega = 0
    for word in words:
        if word in negative_words:
                nega += 1
    return nega
def writedataFile(resultingDataFile):
    arg = '"Number of Retweets", "Number of Replies", "Positive Score","Negative Score","Net Score"'
    resultingDataFile.write(arg)
    resultingDataFile.write('\n')

    linesPTDF = projectTwitterDataFile.readlines()
    headerDontUsed = linesPTDF.pop(0)
    for linesTD in linesPTDF:
        listTD = linesTD.strip().split(',')
        newstr = strip_punctuation(listTD[0])
        postweet = get_pos(newstr)
        negtweet = get_neg(newstr)
        resultingDataFile.write("{}, {}, {}, {}, {}".format(listTD[1], listTD[2], postweet, negtweet, (postweet - negtweet)))
        resultingDataFile.write("\n")


writedataFile(resultingDataFile)
projectTwitterDataFile.close()
resultingDataFile.close()





















